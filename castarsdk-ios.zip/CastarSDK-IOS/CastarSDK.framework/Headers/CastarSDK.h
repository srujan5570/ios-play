//
//  CastarSDK.h
//  CastarSDK
//
//  Created by 电脑 on 2025/6/16.
//

#import <Foundation/Foundation.h>

//! Project version number for CastarSDK.
FOUNDATION_EXPORT double CastarSDKVersionNumber;

//! Project version string for CastarSDK.
FOUNDATION_EXPORT const unsigned char CastarSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CastarSDK/PublicHeader.h>

#import <CastarSDK/CSDK.h>
